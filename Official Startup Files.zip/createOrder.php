<?php
include __DIR__ . "/includes/init.php";

// Catch the post details
if (!isset($_POST['order']) || !isset($_POST['product']) || !isset($_POST['coin'])) {
    exit(header('Location: index.php'));
} else {
    // Post data found, create an address for them to pay to
    // Import the BlockchainAPI generate address's function here

    $sendToString = '';

    // Get the product they clicked
    $productID = $_POST['product'];
    $coin = $_POST['coin'];

    // Get the products information from our functions with the products ID
    $productInformation = $functions->getProductInfo($productID);

    $productAmount = $productInformation['price'];
    $productName = $productInformation['name'];
    $productID = $productInformation['id'];
    $productCurrency = $productInformation['currency'];

    $btc_to_send = $convert->toBtc($productAmount, $productCurrency);
    $eth_to_send = $convert->toCurrency('ETH', $btc_to_send);

    //Let's specify the random here so we can later get the order details back to show to them
    $orderRandom = $functions->orderRandom();

    // Attempt to create a new address for our customers to pay to
    if ($coin == 'BTC') {
        // Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
        $ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL_BTC);
        $makeAddressInfoArray = $functions->generateBTCAddress($ourCallbackUrl, MY_BTC_ADDRESS);
    } else if ($coin == 'ETH') {
        // Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
        $ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL_ETH);
        $makeAddressInfoArray = $functions->generateETHAddress($ourCallbackUrl, MY_ETH_ADDRESS);
    } else {
        // Default to BTC
        // Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
        $ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL_BTC);
        $makeAddressInfoArray = $functions->generateBTCAddress($ourCallbackUrl, MY_BTC_ADDRESS);
    }

    // Now we have the address, we can make the order for them
    if (!empty($makeAddressInfoArray['addressCreated'])) {
        // Good, address created IS NOT null, add it to their new order
        $functions->makeOrder($productCurrency, $orderRandom, 'awaiting_payment', $productAmount, $makeAddressInfoArray['addressCreated'], $productID, 0, htmlspecialchars($makeAddressInfoArray['text'], ENT_QUOTES), 0, $btc_to_send, $eth_to_send, $coin);
        // Redirect them to their order page
        exit(header('Location: pay.php?order=' . $orderRandom));
    } else {
        // Address was null, show some sort of error with the result of the generateBTCAddress - text variable inside the array we made
        die($makeAddressInfoArray['text']);
    }
}
