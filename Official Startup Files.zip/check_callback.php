<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
$layouts->header();
?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Check Callbacks</h1>
  <p class="lead">Check below to see how you can tell if a payment has been made or not</p>
</div>


<div class="container">

  <div class="mb-3 text-center">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST">
      <!-- Let's just create a really simple product we can use our system with -->
      <div class="row">

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Bitcoin</h4>
          </div>
          <div class="card-body">

<div style="max-width: 100%!important;">
<pre class="code code-php"><label>PHP</label><code>// Payment Settings
$my_address = "1LisLsZd3bx8U1NYzpNHqpo8Q6UCXKMJ4z";
$desiredConfirmations = 3;

// If you're using a secret, put it in here
$secret = "7j0ap91o99cxj8k9";

// Start of checks
if(!isset($_GET['secret'])) {
    die('No secret found.');
}

if ($_GET["secret"] !== $secret) die();

// Make sure we have all the POST variables we want to get
if(!$_POST['input_address'] || !$_POST['input_transaction_hash'] || !$_POST['transaction_hash'] || !$_POST['value'] || !$_POST['confirmations'] || !$_POST['destination_address']) {
    die('One of more of the POST variables was not set in the request to our callback url.');
}
    
if ($_POST["destination_address"] !== $my_address) die();

$input_address = $_POST["input_address"];
$input_transaction_hash = $_POST["input_transaction_hash"];
$transaction_hash = $_POST["transaction_hash"];
$value_in_btc = $_POST["value"];
$confirmations = $_POST["confirmations"];

// Confirmation check to make sure the confirmations is above our desired amount
if($confirmations >= $desiredConfirmations) {
    // We should store the payment as soon as we receive it inside this callback file
    // We can later update details such as confirms if needed
} else {
    // Transaction has not reached our desired number of confirmations.
    // Keep waiting for confirmations to be larger
}</code></pre>
</div>

          </div>
        </div>

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Ethereum</h4>
          </div>
          <div class="card-body">

<div style="max-width: 100%!important;">
<pre class="code code-php"><label>PHP</label><code>// Payment Settings
$my_address = "0xd85f18d58982db82e1916d84bc9ecec2a6e93d45"; // Your destination address
$desiredConfirmations = 12;

// If you're using a secret, put it in here
$secret = "7j0ap91o99cxj8k9";

// Start of checks
if(!isset($_GET['secret'])) {
    die('No secret found.');
}

if ($_GET["secret"] !== $secret) die();

// Make sure we have all the POST variables we want to get
if(!$_POST['input_address'] || !$_POST['input_transaction_hash'] || !$_POST['transaction_hash'] || !$_POST['valueWEI'] || !$_POST['gas'] || !$_POST['gasPrice'] || !$_POST['valueETH'] || !$_POST['confirmations'] || !$_POST['destination_address']) {
    die('One of more of the POST variables was not set in the request to our callback url.');
}
    
if ($_POST["destination_address"] !== $my_address) die();

$gas = $_POST["gas"];
$gasPrice = $_POST["gasPrice"];

$value_in_eth = $_POST["valueETH"];
$value_in_wei = $_POST["valueWEI"];

$transaction_fee = ($gasPrice * $gas); // Transaction fee in WEI

$input_address = $_POST["input_address"];
$input_transaction_hash = $_POST["input_transaction_hash"];
$transaction_hash = $_POST["transaction_hash"];
$confirmations = $_POST["confirmations"];

// Work out the real amount they sent to the our address
$totalSent = bcsub($value_in_wei, $transaction_fee); // Use BCMath extension to use this - it's for huge/large numbers that do not fit into 32bit

// Confirmation check to make sure the confirmations is above our desired amount
if($confirmations >= $desiredConfirmations) {
    // Insert your data into a database so you can later on, fetch that data and update it
} else {
    // Transaction has not reached our desired number of confirmations.
    // Keep waiting for confirmations to be larger
}</code></pre>
</div>

          </div>
        </div>

      </div>
  </div>

<?php
    $layouts->footer();
?>