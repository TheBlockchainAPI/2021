<?php
	include __DIR__. "/includes/init.php";

	// Here is where BlockchainAPI will send POST data once your payment has been received

	// First we will need some authentication to see if the request was sent by BlockchainAPI
	// As we provided them our secret, we can use that as our authentication

	// Make sure a secret is even set
	if(!isset($_GET['secret']) || empty($_GET['secret'])) {
		$functions->logToFile('No secret provided');
		die('No secret was provided');
	}

	// This is a CUSTOM parameter we will use for just our site
	// You can add as many GET variables as you like inside your callback URL, and they will all be parsed to the callback url location
	if(!isset($_GET['orderNumber']) || empty($_GET['orderNumber'])) {
		$functions->logToFile('OrderNumber not set');
		die('No order number was provided');
	}

	// Make sure the secret provided by BlockchainAPIs request matches our one
	if ($_GET["secret"] !== SECRET) {
		$functions->logToFile('Secret mismatch');
		die('Secret did not match the real secret');
	}

	// Make sure all POST variables are sent
	if(!isset($_POST['input_address']) || !isset($_POST['input_transaction_hash']) || !isset($_POST['transaction_hash']) || !isset($_POST['value']) || !isset($_POST['confirmations']) || !isset($_POST['destination_address'])) {
		$functions->logToFile('Not all post data was found');
		die('One of more of the POST variables was not set in the request to our callback url.');
	}

	// Make sure the destination address matches ours
	if ($_POST["destination_address"] !== MY_BTC_ADDRESS) {
		$functions->logToFile('Address did not match our bitcoin address');
		die('Address\'s do not match');
	}

	// If we make it this far, it means we're ready to get the data sent by BlockchainAPI
	$input_address = $_POST["input_address"];
	$input_transaction_hash = $_POST["input_transaction_hash"];
	$transaction_hash = $_POST["transaction_hash"];
	$value_in_btc = $_POST["value"];
	$confirmations = $_POST["confirmations"];
	
	$orderNumber = $_GET['orderNumber'];

	$functions->logToFile('Good, we made it this far');

	// Check that this order exists
	$checkOrder = $functions->getOrderInfoWhere('orderNumber', $orderNumber);

	if(!empty($checkOrder)) {
		// Good, order exists, continue with the confirm checks

		$functions->logToFile('Good, order '.$orderNumber.' exists');

		if($confirmations <= 1) {
			// 0 Confirmations, update from awaiting_funds to pending | also, insert the amountPaid value in bitcoin
			$q = $dbh->prepare('UPDATE orders SET status = ?, crypto_paid = ? WHERE orderNumber = ?');
			$q->execute(['pending', $value_in_btc, $orderNumber]);

			$functions->logToFile('1 or less confirms, updated!');
		} else if($confirmations >= 3) {
			// 3 or more confirmations, update order to completed | also, insert the amountPaid value in bitcoin
			$q = $dbh->prepare('UPDATE orders SET status = ?, crypto_paid = ? WHERE orderNumber = ?');
			$q->execute(['completed', $value_in_btc, $orderNumber]);

			$functions->logToFile('3 or more confirms, updated!');
		} else {
			$functions->logToFile('ELSE statement - Confirms value was: '.$confirmations);
		}

		// So now, we have fully created an order system where the buyer selects a product, pays to the generated bitcoin address, then can see the value of status update real-time every 5 seconds to show the user if the payment
		// is completed or if it isn't

	} else {
		$functions->logToFile('Order does not exist in the database');
		die('Order does not exist in the database');
	}
