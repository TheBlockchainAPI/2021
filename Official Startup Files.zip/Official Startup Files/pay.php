<?php

use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;

include __DIR__ . "/includes/init.php";
$layouts->header();

// Check pay post value
if ($_GET['order']) {

  // Grab the order from the database
  $order = (string)$_GET['order'];
  $checkOrder = $functions->getOrderInfoWhere('orderNumber', $order);

  if (!empty($checkOrder)) {

    // Get the product id so we can get details from the product
    $productID = $checkOrder['productID'];

    // Get the products information from our functions with the products ID
    $productInformation = $functions->getProductInfo($productID);
    $productAmount = $productInformation['price'];
    $productName = $productInformation['name'];
    $productID = $productInformation['id'];

    //Let's specify the random here so we can later get the order details back to show to them
    $orderRandom = $order;

    // Get the order payment details from the database
    $generatedAddress = $checkOrder['addressCreated'];
    $estimatedFee = $checkOrder['estimated_transaction_fee'];
    $paymentText = $checkOrder['paymentText'];

    // Get the order details from the database
    $orderNumber = $checkOrder['orderNumber'];
    $orderDateCreated = $checkOrder['dateCreated'];
    $orderStatus = $checkOrder['status'];
    $orderAmount = $checkOrder['amount'];
    $orderAddressCreated = $checkOrder['addressCreated'];
    $orderProductID = $checkOrder['productID'];
    $orderCoin = $checkOrder['coin'];

    // Check their coin type
    if ($orderCoin == 'BTC') {
      // Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
      $ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL_BTC);
      $qrImage = $functions->bitcoinQR($generatedAddress);
      $toSend = $checkOrder['btc_to_send'];
    } else if ($orderCoin == 'ETH') {
      // Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
      $ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL_ETH);
      $qrImage = $functions->ethereumQR($generatedAddress);
      $toSend = $checkOrder['eth_to_send'];
    } else {
      // Default to BTC
      // Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
      $ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL_BTC);
      $qrImage = $functions->bitcoinQR($generatedAddress);
      $toSend = $checkOrder['btc_to_send'];
    }
  } else {
    exit(header('Location: index.php'));
  }
} else {
  exit(header('Location: index.php'));
}

?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Complete your order</h1>
  <p class="lead">Check to make sure the details below are correct</p>
</div>

<div class="container">

  <div class="card-deck mb-3 text-center" style="display: block;;">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST" action="./pay.php">
      <!-- Let's just create a really simple product we can use our system with -->

      <div class="card mb-4 box-shadow block">
        <div class="card-header">
          <h4 class="my-0 font-weight-normal">Please complete the payment below</h4>
        </div>
        <div class="card-body">

          <div class="paymentBox">
            <h1>Payment details</h1>
            <p>To complete your order, please complete the following step(s): </p>

            <p><?= htmlspecialchars_decode($paymentText); ?></p></a>

            <div class="paymentBox" style="border-bottom: 5px solid; padding: 20px 0 20px 0; margin-bottom: 30px; background: white; border-radius: 10px; color: black; font-size: 20px;">
              <p>Or you can get the address by scanning this QR code:<br><?= $qrImage; ?></p>
              <p>Make sure you send <b>EXACTLY</b> <b><a href="javascript:void(0)" onclick="copyToClipboard(this)"><?= $toSend; ?></a></b> <?= $orderCoin; ?></p>
            </div>
          </div>

          <div class="statusBox">
            <p>Once you complete your order, the status will automatically update without refreshing.</p>
          </div>

          <div class="paymentBox">

            <div class="paymentBox" style="border-bottom: 5px solid; padding: 20px 0 20px 0; margin-bottom: 30px; background: white; border-radius: 10px; color: black; font-size: 20px;">
              <span id="paymentTextType" class="badge badge-warning" style="margin-bottom: 20px; padding: 20px;">
                Payment has not yet been found
              </span>
              <div class="statusBox">
                <img src="./assets/img/walk.gif" id="loadingImg" alt="Payment has not been found yet">
              </div>
            </div>
          </div>

          <a href="" class="btn btn-lg btn-block btn-primary">Check payment status manually</a>
        </div>

      </div>

    </form>
  </div>

  <?php
  $layouts->footer();
  ?>

  <script type="text/javascript">
    // Let's make an ajax auto payment checker
    // We want it to update the payment status in the database every 5 seconds
    function checkPayment() {
      // Make an AJAX post to a file where we will do our php to check the database
      // BlockchainAPI will automatically send data to your callback url, firstly as soon as our node sees the payment, then every confirmation up until 6 confirmations or up to 20 bad or successful callbacks.
      // We will post the order ID and get ONLY THE STATUS back as that's all we need
      var orderNum = "<?= $orderRandom; ?>";

      var postForm = { //Fetch form data
        'orderNumber': orderNum
      };

      $.ajax({
        url: "checkOrder.php",
        type: "POST",
        data: postForm,
        dataType: 'json',
        success: function(response) {

          if (response.status) {
            if (response.status == 'awaiting_payment') {

              // Make the label orange still

            } else if (response.status == 'pending') {

              // Make the label orange still
              $('#paymentTextType').removeClass('badge badge-warning');
              $('#paymentTextType').removeClass('badge badge-success');
              $('#paymentTextType').addClass('badge badge-primary');
              $('#paymentTextType').html('Payment has been found but is still pending' + ' <b><a style="color: white; " href="javascript:void(0)" onclick="copyToClipboard(this)">' + response.amount_paid + ' ' + response.coin + '</a> <i class="fas fa-battery-half"></i></b>');

            } else if (response.status == 'completed') {

              // Make the label orange still
              $('#paymentTextType').removeClass('badge badge-warning');
              $('#paymentTextType').removeClass('badge badge-primary');
              $('#paymentTextType').addClass('badge badge-success');
              $('#paymentTextType').html('Payment has been fully paid' + ' <br><br><b><a style="color: white; " href="javascript:void(0)" onclick="copyToClipboard(this)">' + response.amount_paid + ' ' + response.coin + '</a> <i class="fa fa-check"></i><br><br><a target="_blank" style="color: white; " href="https://blockchain.com/btc/tx/' + response.txid + '">https://blockchain.com/btc/tx/' + response.txid + '</a></b>');
              $('#loadingImg').attr('src', './assets/img/' + response.coin +'.gif');

            } else {
              // Default to the awaiting_payment label
            }
          }

          console.log('Checking payment status');

        },
        error: function(jqXHR, msg, type) {
          console.log(msg, type);
        }
      });
    }

    checkPayment();

    // Check every 5 seconds
    setInterval(function() {
      checkPayment();
    }, 5000);
  </script>