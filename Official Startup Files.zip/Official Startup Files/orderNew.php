<?php

use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;

include __DIR__ . "/includes/init.php";
$layouts->header();

?>

<script>
  function showPrice(value) {
    var price = $("#coin option:selected").attr("price");
    var symbol = $("#coin option:selected").attr("symbol");
    $('#cryptoPrice').html(price + ' ' + value + ' ' + symbol);
  }
</script>

<?php

if (isset($_POST['product'])) {
  // Select all from this product
  // Get the products information from our functions with the products ID
  $productID = $_POST['product'];
  $productInformation = $functions->getProductInfo($productID);
  $productAmount = $productInformation['price'];
  $productName = $productInformation['name'];
  $productCurrency = $productInformation['currency'];

  $btcPrice = $convert->toBtc($productAmount, $productCurrency);
  $ethPrice = $convert->toCurrency('ETH', $btcPrice);
}

?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Complete your order</h1>
  <p class="lead">Check to make sure the details below are correct</p>
</div>

<div class="container">

  <div class="card-deck mb-3 text-center" style="display: block;;">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST" action="./createOrder.php">

      <input type="hidden" name="product" value="<?=$productID;?>">

      <!-- Let's just create a really simple product we can use our system with -->

      <div class="card mb-4 box-shadow block">
        <div class="card-header">
          <h4 class="my-0 font-weight-normal"><b><?= $productName; ?></b></h4>
        </div>
        <div class="card-body">

          <ul class="list-unstyled mt-3 mb-4">
            <li>Order amount: <?= $functions->getCurrencySymbol($productCurrency); ?><?= $productAmount; ?> <?= $productCurrency; ?> | <b><?= $btcPrice; ?></b> <i class="fab fa-btc"></i> BTC | <b><?= $ethPrice; ?></b> <i class="fab fa-ethereum"></i> ETH</li>
          </ul>

          <div class="form-group">
            <label for="coin">Select a coin to pay with</label>
            <select name="coin" id="coin" class="form-control" onchange="showPrice(this.value)" style="width: 100%; text-align-last:center;">
              <option value="BTC" symbol="<i class='fab fa-btc'></i>" price="<?= $btcPrice; ?>">BTC</option>
              <option value="ETH" symbol="<i class='fab fa-ethereum'></i>" price="<?= $ethPrice; ?>">ETH</option>
            </select>
          </div>

          <div class="price" style="margin-bottom: 20px; font-size: 25px;">
            <span id="cryptoPrice"><?=$btcPrice;?> BTC <i class="fab fa-btc"></i></span>
          </div>

          <button type="submit" name="order" class="btn btn-lg btn-block btn-primary">Continue</button>
        </div>

      </div>

    </form>
  </div>

  <?php
  $layouts->footer();
  ?>