<?php
	use Jimmerioles\BitcoinCurrencyConverter\Converter;
	use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;

	// Enable error reporting
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	// We will call this file in every page
	require __DIR__. "/../vendor/autoload.php";
	require __DIR__. "/../config/config.php";
	require __DIR__. "/../helpers/database.php";
	require __DIR__. "/functions.php";
	require __DIR__. "/layouts.php";

	// Database connection
	$database = new Database();
	$dbh = $database->getConnection();

	// Our custom functions class, importing the database above
	$functions = new Functions($dbh);

	$layouts = new Layouts();

	// Crypto converter
	$convert = new Converter(new CoinbaseProvider);
?>