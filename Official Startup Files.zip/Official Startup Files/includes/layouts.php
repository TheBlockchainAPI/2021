<?php

class Layouts {

    public $location = __DIR__.'/../layouts/';

    public function header() {
        require_once($this->location.'header.php');
    }

    public function footer() {
        require_once($this->location.'footer.php');
    }
}

?>