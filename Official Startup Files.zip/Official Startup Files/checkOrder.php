<?php
include __DIR__ . "/includes/init.php";

// This is our file we use to get the orders data using the ajax
// Ajax allows us to use real-time tech so we can show the customers completed order without them refreshing the page

// Make sure we have the post from the ajax call
if (isset($_POST['orderNumber'])) {
	// Continue, we have the data we need
	// Now use our function to get the order data

	$orderNumber = $_POST['orderNumber'];

	$getData = $functions->getOrderInfoWhere('orderNumber', $orderNumber);

	if (!empty($getData)) {
		// Good, not empty, let's get the status and return it as that's all we want to show to the customer every 5 seconds
		$status = $getData['status'];
		$crypto_paid = $getData['crypto_paid'];
		$coin = $getData['coin'];
		$txid = $getData['txid'];

		$return = array(
			'status' => $status,
			'amount_paid' => $crypto_paid,
			'coin' => $coin,
			'txid' => $txid
		);

		echo json_encode($return);
	} else {
		// Data was empty, maybe a wrong orderNumber or the order doesn't exist
		echo json_encode('Select from orders was empty for this order number');
	}
} else {
	// Data we need is not found, kill here
	die();
}
