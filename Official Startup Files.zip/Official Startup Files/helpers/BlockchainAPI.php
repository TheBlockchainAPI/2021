<?php
	
	// Feel free to use this file for very simple usage towards BlockchainAPI.org

	// Bitcoin functions
	class BTCHelpers {

		// Returns array('address', 'estimated_fee');
		public static function generateAddress($secret, $address, $type, $callback) {
			# PHP Example To Generate Address
			$secret = $secret;
			$my_address = $address;
			$addressType = $type; // bech32 | legacy | p2sh-segwit
			$my_callback_url = $callback."&secret=" . $secret;
			$api_base = "https://blockchainapi.org/api/btc";

			$curl = curl_init();
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => $api_base . "?method=create&address_type=".$addressType."&address=" . $my_address . "&callback=" . $my_callback_url
			));

			$response = curl_exec($curl);
			$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

			curl_close($curl);

			$storage = array();

			if ($http_status_code == 200) {
			    $decoded = json_decode($response, true);
			    $storage['address'] = $decoded["success"]["input_address"];
			    $storage['estimated_fee'] = $decoded["success"]["estimated_transaction_fee"];
			} else {
			    return $response;
			}

			return $storage;
		}

		// Returns json of all logs
		public static function checkLogs($callbackUrl) {
			$api_base = "https://blockchainapi.org/api/btc?method=check_logs";

			$curl = curl_init();
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => $api_base.'&callback='.$callbackUrl
			));

			$response = curl_exec($curl);
			$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			curl_close($curl);

			if ($http_status_code == 200) {
			    $decoded = json_decode($response, true);
			    if($decoded['success']) {
			    	return json_encode($decoded['success'], JSON_PRETTY_PRINT);
			    } else {
			    	return json_encode(array('error' => 'The supplied callback URL has never been sent any callbacks\/notifications.'), JSON_PRETTY_PRINT);
			    }
			} else {
			    return $response;
			}
		}

		// Returns json of current fees
		public static function checkfees() {
			$api_base = "https://blockchainapi.org/api/btc?method=check_fees";

			$curl = curl_init();
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => $api_base
			));

			$response = curl_exec($curl);
			$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			curl_close($curl);

			if ($http_status_code == 200) {
			    $decoded = json_decode($response, true);
			    if($decoded['success']) {
			    	return json_encode($decoded['success'], JSON_PRETTY_PRINT);
			    } else {
			    	return json_encode(array('error' => 'Failed to get fees'), JSON_PRETTY_PRINT);
			    }
			} else {
			    return $response;
			}
		}

	}

	// Ethereum functions
	class ETHHelpers {
		
		// Returns json of all logs
		public static function checkLogs($callbackUrl) {
			$api_base = "https://blockchainapi.org/api/eth?method=check_logs";

			$curl = curl_init();
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => $api_base.'&callback='.$callbackUrl
			));

			$response = curl_exec($curl);
			$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			curl_close($curl);

			if ($http_status_code == 200) {
			    $decoded = json_decode($response, true);

			    if($decoded['success']) {
			    	return json_encode($decoded['success'], JSON_PRETTY_PRINT);
			    } else {
			    	return json_encode(array('error' => 'The supplied callback URL has never been sent any callbacks\/notifications.'), JSON_PRETTY_PRINT);
			    }
			} else {
			    return $response;
			}
		}

		// Returns array('address', 'estimated_fee');
		public static function generateAddress($secret, $address, $callback) {
			# PHP Example To Generate Address
			$secret = $secret;
			$my_address = $address;
			$my_callback_url = $callback."&secret=" . $secret;
			$api_base = "https://blockchainapi.org/api/eth";

			$curl = curl_init();
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => $api_base . "?method=create&address=" . $my_address . "&callback=" . $my_callback_url
			));

			$response = curl_exec($curl);
			$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

			curl_close($curl);

			$storage = array();

			if ($http_status_code == 200) {
			    $decoded = json_decode($response, true);
			    $storage['address'] = $decoded["success"]["account"];
			} else {
			    return $response;
			}

			return $storage;
		}

		// Returns json of current fees
		public static function checkfees() {
			$api_base = "https://blockchainapi.org/api/eth?method=check_fees";

			$curl = curl_init();
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => $api_base
			));

			$response = curl_exec($curl);
			$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			curl_close($curl);

			if ($http_status_code == 200) {
			    $decoded = json_decode($response, true);
			    if($decoded['success']) {
			    	return json_encode($decoded['success'], JSON_PRETTY_PRINT);
			    } else {
			    	return json_encode(array('error' => 'Failed to get fees'), JSON_PRETTY_PRINT);
			    }
			} else {
			    return $response;
			}
		}

	}

	$btcHelpers = new BTCHelpers;
	$ethHelpers = new ETHHelpers;

?>