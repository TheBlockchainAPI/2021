<?php
	include __DIR__. "/includes/init.php";

	// In this page, we will show them their order details and check the status every 5 seconds if their order exists

	// First get the $_GET order number from the url
	if(isset($_GET['o'])) {
		// Good, they have an order in the url, let's check if it's a real order from the database
		if(!empty($_GET['o'])) {
			// Good, the order value is not empty, let's check it's inside the database
			$order = (string)$_GET['o'];
			$checkOrder = $functions->getOrderInfoWhere('orderNumber', $order);

			if(!empty($checkOrder)) {

				// Get the product id so we can get details from the product
				$productID = $checkOrder['productID'];

				// Get the products information from our functions with the products ID
				$productInformation = $functions->getProductInfo($productID);
				$productAmount = $productInformation['price'];
				$productName = $productInformation['name'];
				$productID = $productInformation['id'];

				//Let's specify the random here so we can later get the order details back to show to them
				$orderRandom = $order;

				// Replace the order number in the config CALLBACK_URL we set with the users real order number so we can later check this order in the callback file
				$ourCallbackUrl = str_replace("{ORDER_NUMBER}", $orderRandom, CALLBACK_URL);

				// Get the order payment details from the database
				$generatedAddress = $checkOrder['addressCreated'];
				$estimatedFee = $checkOrder['estimated_transaction_fee'];
				$paymentText = $checkOrder['paymentText'];
				$bitcoinToSend = $checkOrder['btc_to_send'];

				// Get the order details from the database
				$orderNumber = $checkOrder['orderNumber'];
				$orderDateCreated = $checkOrder['dateCreated'];
				$orderStatus = $checkOrder['status'];
				$orderAmount = $checkOrder['amount'];
				$orderAddressCreated = $checkOrder['addressCreated'];
				$orderProductID = $checkOrder['productID'];

				$qrImage = $functions->bitcoinQR($generatedAddress);

			} else {
				exit(header('Location: index.php'));
			}
		} else {
			exit(header('Location: index.php'));
		}
	} else {
		exit(header('Location: index.php'));
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>BlockchainAPI Tutorial To Create Address's</title>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<style type="text/css">
		* {
			margin: 20px;
		}
		body {
			background: black;
			color: white;
			font-family: arial;
		}
		.seperator {
			margin: 50px;
		}
		.product {
			background: grey;
			padding: 30px;
			color: white;
		}
		.buy-button {
			padding: 20px;
			background: black;
			color: white;
			border-radius: 10px;
			border: 0px;
		}
		.paymentBox {
			background: orange;
			padding: 30px;
			border-radius: 10px;
			color: black;
		}
		.orderDetails {
			background: #1190FF;
			padding: 30px;
			border-radius: 10px;
			color: white;
		}
		.statusBox {
			background: green;
			padding: 30px;
			border-radius: 10px;
			color: white;
		}
		.developers {
			background: purple;
			padding: 30px;
			border-radius: 10px;
			color: white;
		}
	</style>
</head>
<body>

	<h1>Order #<span id="orderNum"><?=$orderNumber;?></span></h1>
	<h1>You are buying <b><?=$productName;?></b></h1>

	<div class="seperator"></div>

	<div class="orderDetails">
		<h1>Order details</h1>
		<p>Order number: #<?=$orderNumber;?></p>
		<p>Order amount: $<?=$orderAmount;?> | <?=$bitcoinToSend;?> BTC</p>
		<p>Order address created: <?=$orderAddressCreated;?></p>
		<p>Order status: <span id="status"><?=$orderStatus;?></span></p>
		<p>Created: <?=$functions->howLongAgo($orderDateCreated);?></p>
	</div>

	<div class="paymentBox">
		<h1>Payment details</h1>
		<p>To complete your order, please complete the following step(s): </p>
		<p><?=$paymentText;?></p>
		<p>Or you can get the address by scanning this QR code: <?=$qrImage;?></p>
		<p>Make sure you send EXACTLY: <?=$bitcoinToSend;?> BTC</p>
	</div>

	<div class="statusBox">
		<p>Once you complete your order, the status will automatically update without refreshing.</p>
	</div>

	<div class="developers">
		<p>Your callback url for this payment is: <a href="<?=$ourCallbackUrl;?>" style="color: white;"><?=$ourCallbackUrl;?></a></p>
	</div>

</body>

<script type="text/javascript">

	// Let's make an ajax auto payment checker
	// We want it to update the payment status in the database every 5 seconds
	function checkPayment() {
		// Make an AJAX post to a file where we will do our php to check the database
		// BlockchainAPI will automatically send data to your callback url, firstly as soon as our node sees the payment, then every confirmation up until 6 confirmations or up to 20 bad or successful callbacks.
		// We will post the order ID and get ONLY THE STATUS back as that's all we need
		var orderNum = "<?=$orderRandom;?>";

        var postForm = { //Fetch form data
            'orderNumber' : orderNum
        };

		$.ajax({
			url: "checkOrder.php",
			type: "POST",
			data: postForm,
			success: function (response) {
				$('#status').html(response);
			},
			error: function(jqXHR, msg, type) {
				console.log(msg, type);
			}
		});
	}

	// Run this every 5 seconds
	setInterval(function(){
		checkPayment();
	}, 5000);

</script>

</html>