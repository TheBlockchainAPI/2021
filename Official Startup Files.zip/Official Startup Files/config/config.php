<?php
	// Let's make our config

	// Our database settings
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'BlockchainAPI_video_files');
	define('DB_USER', 'root');
	define('DB_PASS', 'password1');

	// Website details
	define('WEBSITE_NAME', 'BlockchainAPI');
	define('WEBSITE_DESCRIPTION', 'BlockchainAPI is the easiest, most reliable Bitcoin and Ethereum payment processor on the internet. No signup, no BS. Straight to the point.');
	define('WEBSITE_FAVICON', 'https://blockchainapi.org/images/blockchainapifavicon.png');

	// BlockchainAPI config settings for our website
	define('SECRET', 'df8fuyidsjfdsfsdfoif9sfi');
	define('CALLBACK_URL_BTC', 'https://cryptosprints.com/callbackCheckerBTC.php?orderNumber={ORDER_NUMBER}&secret='.SECRET);
	define('CALLBACK_URL_ETH', 'https://cryptosprints.com/callbackCheckerETH.php?orderNumber={ORDER_NUMBER}&secret='.SECRET);
	define('MY_BTC_ADDRESS', '3Hpu14TBY15Gy23GcCStoCuEETbuULXtnt');
	define('MY_ETH_ADDRESS', '0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B');
?>