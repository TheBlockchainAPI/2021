<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
$layouts->header();

$error = null;

// Check order post
if(isset($_POST['checkorder'])) {
  if(isset($_POST['orderid'])) {
    $orderID = $_POST['orderid'];

    // Check the order id from our database
    $checkOrder = $functions->getOrderInfoWhere('orderNumber', $orderID);

    if($checkOrder) {
      exit(header('Location: pay.php?order='.$orderID));
    } else {
      $error = 'Order ID was not found';
    }
  }
}

?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Check Order</h1>
  <p class="lead">Enter your order number and check the status of your order on our site</p>
</div>


<div class="container">

  <div class="mb-3 text-center">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST">
      <!-- Let's just create a really simple product we can use our system with -->
      <div class="row">

        <?php

          if(!empty($error)) {
            echo '
            <div class="alert alert-danger" style="width: 100%;" role="alert">
              '.$error.'
            </div>
            ';
          }

        ?>

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-body">
            <div class="form-group">
              <input type="text" class="form-control" name="orderid" style="text-align: center;" placeholder="Enter your order id">
            </div>

            <button type="submit" name="checkorder" class="btn btn-lg btn-block btn-primary">Check Order</button>

          </div>
        </div>

      </div>
    </form>
  </div>

<?php
    $layouts->footer();
?>