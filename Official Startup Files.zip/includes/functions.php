<?php

use Symfony\Component\Intl\Currencies;

// We will write our custom functions inside here
class Functions
{

	// Define our database variable so we can use our database
	public function __construct($database)
	{
		$this->db = $database;
	}

	# Start of Products

	// Return an array of products
	public function getProducts()
	{
		$q = $this->db->prepare('SELECT * FROM products');
		$q->execute();
		return $q;
	}

	// Return info about 1 product
	public function getProductInfo($id)
	{
		$q = $this->db->prepare('SELECT * FROM products WHERE id = ?');
		$q->execute([$id]);
		$q = $q->fetch(PDO::FETCH_ASSOC);
		return $q;
	}

	# End of Products

	# Start of orders

	// Return an array of orders
	public function getOrders()
	{
		$q = $this->db->prepare('SELECT * FROM orders');
		$q->execute();
		return $q;
	}

	// Return info about 1 order
	public function getOrderInfoWhere($where, $value)
	{
		$q = $this->db->prepare('SELECT * FROM orders WHERE ' . $where . ' = ?');
		$q->execute([$value]);
		$q = $q->fetch(PDO::FETCH_ASSOC);
		return $q;
	}

	// Return info about 1 product
	public function makeOrder($currency, $orderNumber, $status, $amount, $address, $productID, $crypto_paid, $paymentText, $estimatedTransactionFee, $btcToSend, $ethToSend, $coin)
	{
		$q = $this->db->prepare('INSERT INTO orders SET currency = ?, orderNumber = ?, status = ?, amount = ?, addressCreated = ?, productID = ?, crypto_paid = ?, paymentText = ?, estimated_transaction_fee = ?, btc_to_send = ?, eth_to_send = ?, coin = ?');
		$q->execute([$currency, $orderNumber, $status, $amount, $address, $productID, $crypto_paid, $paymentText, $estimatedTransactionFee, $btcToSend, $ethToSend, $coin]);
	}

	// Update order status and amount paid
	public function updateOrder($amount_paid, $status)
	{
	}

	# End of orders

	# Start of BlockchainAPI functions 

	// Generate an address for our customers to pay to
	public function generateBTCAddress($callbackUrl, $bitcoinAddress)
	{
		$toReturn = array();

		$my_callback_url = $callbackUrl;
		$api_base = "https://blockchainapi.org/api/btc";
		$addressType = "segwit";

		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $api_base . "?method=create&address_type=" . $addressType . "&setting=catch_all&address=" . $bitcoinAddress . "&callback=" . $my_callback_url
		));

		$response = curl_exec($curl);
		$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);

		# If we get a good, 200 http status code, get the payment details: input_address & estimated_transaction_fee
		if ($http_status_code == 200) {
			$decoded = json_decode($response, true);

			$sendToString = "Please send the payment amount shown above to the following Bitcoin address:<br><b><a href=javascript:void(0) onclick=copyToClipboard(this)>" . $decoded["success"]["input_address"] . '</a></b><br>';
			$sendToString .= "The current estimated fee is:<br><b>" . $decoded["success"]["estimated_transaction_fee"] . " BTC <i class='fab fa-btc'></i></b>";

			$toReturn['addressCreated'] = $decoded["success"]["input_address"];
			$toReturn['estimatedFee'] = $decoded["success"]["estimated_transaction_fee"];
			$toReturn['text'] = $sendToString;
		} else {
			$toReturn['text'] = "Sorry, an error occurred";
		}
		return $toReturn;
	}

	public function generateETHAddress($callbackUrl, $ethereumAddress)
	{
		$toReturn = array();

		$my_callback_url = $callbackUrl;
		$api_base = "https://blockchainapi.org/api/eth";

		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $api_base . "?method=create&address=" . $ethereumAddress . "&callback=" . $my_callback_url
		));

		$response = curl_exec($curl);
		$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);

		# If we get a good, 200 http status code, get the payment details: account
		if ($http_status_code == 200) {

			$decoded = json_decode($response, true);
			$sendToString = "Please send the payment to the following Ethereum address:<br><b><a href=javascript:void(0) onclick=copyToClipboard(this)>" . $decoded["success"]["account"] . "</a></b>";

			$toReturn['addressCreated'] = $decoded["success"]["account"];
			$toReturn['text'] = $sendToString;
		} else {
			$toReturn['text'] = "Sorry, an error occurred";
		}
		return $toReturn;
	}


	public function btcToSatoshi($value)
	{
		return bcdiv(intval($value), 100000000, 8);
	}

	public function satoshiToBtc($value)
	{
		$BTC = $value / 100000000;
		return $BTC;
	}

	function wei2eth($wei)
	{
		return bcdiv($wei, '1000000000000000000', 18);
	}

	public function formatBTC($value)
	{
		$value = sprintf('%.8f', $value);
		$value = rtrim($value, '0');
		return $value;
	}

	public function usdToBtc($usd)
	{
		$url = "https://bitpay.com/api/rates";
		$json = file_get_contents($url);
		$data = json_decode($json, TRUE);
		$rate = $data[2]["rate"];
		$bitcoin_price = round($usd / $rate, 8);
		return $bitcoin_price;
	}

	public function bitcoinQR($address)
	{
		return '<img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=bitcoin:' . $address . '" alt="Bitcoin QR code for address: ' . $address . '" title="Bitcoin QR code for address: ' . $address . '" style="width: 200px; height: 200px; border-radius: 15px; margin: 20px;" />';
	}

	public function ethereumQR($address)
	{
		return '<img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=ethereum:' . $address . '" alt="Ethereum QR code for address: ' . $address . '" title="Ethereum QR code for address: ' . $address . '" style="width: 200px; height: 200px; border-radius: 15px; margin: 20px;" />';
	}

	# End of BlockchainAPI functions

	# Start of core functions

	public function random()
	{
		return bin2hex(random_bytes(50));
	}

	public function orderRandom()
	{
		return bin2hex(random_bytes(10)) . '-' . bin2hex(random_bytes(10)) . '-' . bin2hex(random_bytes(10)) . '' . bin2hex(random_bytes(10));
	}

	public function howLongAgo($datetime, $full = false)
	{
		$now = new DateTime;
		$ago = new DateTime($datetime);
		$diff = $now->diff($ago);

		$diff->w = floor($diff->d / 7);
		$diff->d -= $diff->w * 7;

		$string = array(
			'y' => 'year',
			'm' => 'month',
			'w' => 'week',
			'd' => 'day',
			'h' => 'hour',
			'i' => 'minute',
			's' => 'second',
		);
		foreach ($string as $k => &$v) {
			if ($diff->$k) {
				$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
			} else {
				unset($string[$k]);
			}
		}

		if (!$full) $string = array_slice($string, 0, 1);
		return $string ? implode(', ', $string) . ' ago' : 'just now';
	}

	public function logToFile($text)
	{
		$fp = fopen('log.log', 'a');
		fwrite($fp, date('Y-m-d H:i:s') . ' - ' . $text . "\n");
		fclose($fp);
	}

	function getCurrencySymbol($currency)
	{
		\Locale::setDefault('en');
		$symbol = Currencies::getSymbol("$currency");
		return $symbol;
	}

	# End of core functions

	# Start of payment status's #

	function checkStatusLabel($status)
	{
		switch ($status) {
			case 'awaiting_payment':
				$label = 'warning';
				break;
			case 'pending':
				$label = 'primary';
				break;
			case 'completed':
				$label = 'success';
				break;
			default:
				$label = 'warning';
				break;
		}
		return $label;
	}

	# End of payment status's


}
