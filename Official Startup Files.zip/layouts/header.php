<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?= WEBSITE_DESCRIPTION; ?>">
  <meta name="author" content="">
  <link rel="icon" href="<?= WEBSITE_FAVICON; ?>">

  <title><?= WEBSITE_NAME; ?> - Home</title>

  <link rel="canonical" href="index.html">

  <!-- Bootstrap core CSS -->
  <link href="./assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="./assets/dist/css/custom.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./assets/dist/css/pricing.css" rel="stylesheet">
  <!-- Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js" integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>

  <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
    <h5 class="my-0 mr-md-auto font-weight-normal"><a style="color: black; text-decoration: none;" href="index.php"><?= WEBSITE_NAME; ?></a></h5>
    <nav class="my-2 my-md-0 mr-md-3">
      <a class="p-2 text-dark" href="index.php">Home</a>
      <a class="p-2 text-dark" href="shop.php">Shop Example</a>
      <a class="p-2 text-dark" href="generate_address.php">Generate Address</a>
      <a class="p-2 text-dark" href="check_callback.php">Check Callback</a>
      <a class="p-2 text-dark" href="check_logs.php">Check Logs</a>
      <a class="p-2 text-dark" href="check_fees.php">Check Fees</a>
      <a class="p-2 text-dark" href="check_order.php">Check Order</a>
    </nav>
    <a class="btn btn-outline-primary" href="https://blockchainapi.org">BlockchainAPI</a>
  </div>