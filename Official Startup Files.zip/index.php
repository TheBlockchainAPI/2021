<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
$layouts->header();
?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Home</h1>
  <p class="lead">Welcome to the <a href="https://BlockchainAPI.org" target="_blank">BlockchainAPI.org</a> official startup files</p>
</div>


<div class="container">

  <div class="mb-3 text-center">

    <p>With our new files, you should find it very very easy to start accepting crypto into your applications.</p>
    <p>We have created these files which allow you to:</p>
    <ul>
      &#8226; Setup basic products with price, currency, name, description etc.<br>
      &#8226; A fully working automated Bitcoin and Ethereum shop<br>
      &#8226; Generate address production and example with code<br>
      &#8226; Check logs for a callback url with code<br>
      &#8226; Check current fees with code<br>
      &#8226; Check order on site by entering order id<br>
      &#8226; Detect once payments are made and update the database
    </ul>

    <p style="font-weight: bold;">We also included a helper package to help you easily intergrate BlockchainAPI.<br>You can find these files inside /helpers/BlockchainAPI.php</p>

    <p>Should you need any help, simply contact us on discord or open an on-site support ticket <a href="https://blockchainapi.org//tickets/new" target="_blank">here</a>.</p>

    <h3>Click the Discord icon below to join our group</h3> <br>

    <a href="https://discord.gg/2w8m6BVDvk" target="_blank">
      <img src="./assets/img/discord.png" style="width: 100px; height: 100px;">
    </a>

  </div>

<?php
    $layouts->footer();
?>