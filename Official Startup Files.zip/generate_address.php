<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
include __DIR__ . "/helpers/BlockchainAPI.php";
$layouts->header();

$error = null;
$result_address = null;
$result_estimated_fee = null;

// Test BTC address generate
if(isset($_POST['testBTC'])) {

  if(isset($_POST['form_btc_secret']) && isset($_POST['form_btc_address']) && isset($_POST['form_btc_callback']) && isset($_POST['form_btc_address_type'])) {
    // Check if they selected no option for the select
    if($_POST['form_btc_address_type'] == 'none') {
      $error = 'Please select an address type';
    } else {
      // Continue - Make the request to generate a new address
      $form_secret = $_POST['form_btc_secret'];
      $form_address = $_POST['form_btc_address'];
      $form_callback = $_POST['form_btc_callback'];
      $form_address_type = $_POST['form_btc_address_type'];

      // Use the helper functions to make a new address for our customers
      // generateAddress($secret, $address, $type, $callback)
      $result = $btcHelpers::generateAddress($form_secret, $form_address, $form_address_type, $form_callback);

      if($result !== false) {
        // Dig into the array [address, estimated_fee] to show to the customer
        $result_btc_address = $result['address'];
        $result_estimated_fee = $result['estimated_fee'];
      }
    }
  } else {
    $error = 'All field are required';
  }

}

// Test ETH address generate
if(isset($_POST['testETH'])) {

  if(isset($_POST['form_eth_secret']) && isset($_POST['form_eth_address']) && isset($_POST['form_eth_callback'])) {
    // Check if they selected no option for the select

    // Continue - Make the request to generate a new address
    $form_secret = $_POST['form_eth_secret'];
    $form_address = $_POST['form_eth_address'];
    $form_callback = $_POST['form_eth_callback'];

    // Use the helper functions to make a new address for our customers
    // generateAddress($secret, $address, $type, $callback)
    $result = $ethHelpers::generateAddress($form_secret, $form_address, $form_callback);

    if($result !== false) {
      // Dig into the array [address, estimated_fee] to show to the customer
      $result_eth_address = $result['address'];
    }
  } else {
    $error = 'All field are required';
  }

}

?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Generate An Address</h1>
  <p class="lead">Check out how to generate a new address for your customers below</p>
</div>


<div class="container">

  <div class="mb-3 text-center">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST">
      <!-- Let's just create a really simple product we can use our system with -->
      <div class="row">

        <?php

          if(!empty($error)) {
            echo '
            <div class="alert alert-danger" style="width: 100%;" role="alert">
              '.$error.'
            </div>
            ';
          }
        ?>

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Bitcoin</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" style="font-size: 14px;"></h1>
            <h1 class="card-title pricing-card-title" style="font-size: 14px;"> <i class="fab fa-btc"></i> BTC</h1>

            <div class="form-group">
              <input type="text" class="form-control" name="form_btc_secret" style="text-align: center;" placeholder="Enter your secret" required>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="form_btc_address" style="text-align: center;" placeholder="Enter your Bitcoin address" required>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="form_btc_callback" style="text-align: center;" placeholder="Enter your callback url with any invoice number" required>
            </div>
            <div class="form-group">
              <select class="form-control" name="form_btc_address_type">
                <option value="none">Select an address type</option>
                <option value="bech32">bech32</option>
                <option value="legacy ">legacy</option>
                <option value="p2sh-segwit">p2sh-segwit</option>
              </select>
            </div>

            <button type="submit" name="testBTC" class="btn btn-lg btn-block btn-primary">Test Generate Address</button>

            <div id="btcResult" style="margin-top: 20px; margin-bottom: 20px;">
              <?php

                if(!empty($result_btc_address) && !empty($result_estimated_fee)) {
                  echo '
                  <div class="alert alert-success" style="width: 100%;" role="alert">
                    Address: '.$result_btc_address.'<br>
                    Estimated Fee: '.$result_estimated_fee.'
                  </div>
                  ';
                }

              ?>
            </div>
          </form>
          <form method="POST">

<div style="max-width: 100%!important;">
<pre class="code code-php"><label>PHP</label><code># PHP Example To Generate Address
$secret = "7j0ap91o99cxj8k9";
$my_address = "1LisLsZd3bx8U1NYzpNHqpo8Q6UCXKMJ4z";
$addressType = "bech32"; // bech32 | legacy | p2sh-segwit
$my_callback_url = "http://example.com/callback?invoice_id=1234&amp;secret=" . $secret;
$api_base = "https://blockchainapi.org/api/btc";

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER =&gt; 1,
    CURLOPT_URL =&gt; $api_base . "?method=create&amp;address_type=".$addressType."&address=" . $my_address . "&amp;callback=" . $my_callback_url
));

$response = curl_exec($curl);
$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($http_status_code == 200) {
    $decoded = json_decode($response, true);
    echo "Please send the payment to the following Bitcoin address: " . $decoded["success"]["input_address"];
    echo "The current estimated fee is: ".$decoded["success"]["estimated_transaction_fee"].' BTC';
} else {
    echo "Sorry, an error occurred: " . $response;
}</code></pre>
</div>

          </div>
        </div>

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Ethereum</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" style="font-size: 14px;"></h1>
            <h1 class="card-title pricing-card-title" style="font-size: 14px;"> <i class="fab fa-ethereum"></i> ETH</h1>

            <div class="form-group">
              <input type="text" class="form-control" name="form_eth_secret" style="text-align: center;" placeholder="Enter your secret" required>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="form_eth_address" style="text-align: center;" placeholder="Enter your Ethereum address" required>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="form_eth_callback" style="text-align: center;" placeholder="Enter your callback url with any invoice number" required>
            </div>

            <button type="submit" name="testETH" class="btn btn-lg btn-block btn-primary">Test Generate Address</button>

            <div id="ethResult" style="margin-top: 20px; margin-bottom: 20px;">
              <?php

                if(!empty($result_eth_address)) {
                  echo '
                  <div class="alert alert-success" style="width: 100%;" role="alert">
                    Address: '.$result_eth_address.'<br>
                  </div>
                  ';
                }

              ?>
            </div>

<div style="max-width: 100%!important;">
<pre class="code code-php"><label>PHP</label><code># PHP Example To Generate Address
$secret = "7j0ap91o99cxj8k9";
$my_address = "0x89205A3A3b2A69De6Dbf7f01ED13B2108B2c43e7";
$my_callback_url = "http://example.com/callback?invoice_id=1234&secret=" . $secret;
$api_base = "https://blockchainapi.org/api/eth";

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $api_base . "?method=create&address=" . $my_address . "&callback=" . $my_callback_url
));

$response = curl_exec($curl);
$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($http_status_code == 200) {
    $decoded = json_decode($response, true);
    echo "Please send the payment to the following Ethereum address: " . $decoded["success"]["account"];
} else {
    echo "Sorry, an error occurred: " . $response;
}</code></pre>
</div>

          </div>
        </div>

      </div>
    </form>
  </div>

<?php
    $layouts->footer();
?>