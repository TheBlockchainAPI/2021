-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2021 at 05:40 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blockchainapi_video_files`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(255) NOT NULL,
  `orderNumber` varchar(255) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('awaiting_payment','pending','completed','') NOT NULL,
  `amount` varchar(255) NOT NULL,
  `addressCreated` varchar(255) NOT NULL,
  `productID` int(255) NOT NULL,
  `crypto_paid` text NOT NULL,
  `estimated_transaction_fee` varchar(255) NOT NULL,
  `paymentText` text NOT NULL,
  `btc_to_send` varchar(255) NOT NULL,
  `eth_to_send` varchar(255) NOT NULL,
  `coin` enum('BTC','ETH','','') NOT NULL,
  `currency` varchar(255) NOT NULL,
  `txid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `orderNumber`, `dateCreated`, `status`, `amount`, `addressCreated`, `productID`, `crypto_paid`, `estimated_transaction_fee`, `paymentText`, `btc_to_send`, `eth_to_send`, `coin`, `currency`, `txid`) VALUES
(76, '1c726ade51d33aa699b6-d15ee4744ee840c79757-eaa2c47ab3f95a27af164f84dc09f0502ad29d58', '2021-06-11 15:31:08', 'awaiting_payment', '20.00', '0x941c5bb6429cbe1bdbc3d9e4ee6fd8e1d39537b1', 2, '0', '0', 'Please send the payment to the following Ethereum address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;0x941c5bb6429cbe1bdbc3d9e4ee6fd8e1d39537b1&lt;/a&gt;&lt;/b&gt;', '0.00054178', '0.0082664', 'ETH', 'USD', ''),
(77, '805a51c63a0ef124ad98-b5c448ea6d568f873aee-3ca10fe122f19dc30f9fc8eb9e71136e80632b7e', '2021-06-11 16:00:13', 'pending', '20.00', '3FPjChSpWAfNpz88nJjyNfnePbAUEkZE14', 2, '0.000533', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;3FPjChSpWAfNpz88nJjyNfnePbAUEkZE14&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00054105', '0.00825463', 'BTC', 'USD', ''),
(78, '5a7cfcf2c0a09410a2b7-cd7c4b693b025ec0413f-75a1348b4fcb3785c5735505c07c49ecbd5a5ad1', '2021-06-11 16:07:52', 'pending', '10.00', '0x8aeeb5dde42dd066d56a3c5ed91d05a42b6c054f', 3, '0.00543', '0', 'Please send the payment to the following Ethereum address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;0x8aeeb5dde42dd066d56a3c5ed91d05a42b6c054f&lt;/a&gt;&lt;/b&gt;', '0.00038272', '0.00583015', 'ETH', 'GBP', ''),
(79, 'ceb3f0e4019c25c9d1af-0ccb1f265229b19d4500-f33feb3a368295e546dd9c00ff11034863cea30b', '2021-06-11 16:09:38', 'awaiting_payment', '10.00', '3JFx31Ep2oZnm79k3XgfMJ54vrjx63MBMS', 3, '0', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;3JFx31Ep2oZnm79k3XgfMJ54vrjx63MBMS&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00038184', '0.00581231', 'BTC', 'GBP', ''),
(80, '26d058c62ecf9631add9-0b4cebe5e38d238c04da-c2129a8216fe25515f9c81b5978dc707b28a7424', '2021-06-18 13:14:39', 'completed', '10.00', '32Hz2zL37Qn5Ccw2HKg8LQKQrKrDGFLEoy', 3, '0.000533', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;32Hz2zL37Qn5Ccw2HKg8LQKQrKrDGFLEoy&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00036961', '0.00604283', 'BTC', 'GBP', 'dfy8sdfidhsifh8sdyfhsdifdsf'),
(81, 'ec214de78152cb1af83e-a2abea4acaa0efd35e71-8f107bcfdd0afc7fb0ca56e6ff16d427aa5a974c', '2021-06-18 13:14:46', 'awaiting_payment', '10.00', '34n4Ww15HNtptSYKgFcRwd2xwr2vnvmzLS', 3, '0', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;34n4Ww15HNtptSYKgFcRwd2xwr2vnvmzLS&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00037117', '0.00607927', 'BTC', 'GBP', ''),
(82, '31ca29e5a2cfb9212c9a-ca84a90c3447b5b9128b-9d75f8e14c77eea23ba2f28f84836752a7558e25', '2021-06-18 13:16:43', 'awaiting_payment', '10.00', '0xea11ab04497baa5f63be0c1a9076074c29aaa88d', 3, '0', '0', 'Please send the payment to the following Ethereum address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;0xea11ab04497baa5f63be0c1a9076074c29aaa88d&lt;/a&gt;&lt;/b&gt;', '0.00037278', '0.00610464', 'ETH', 'GBP', ''),
(83, '446d12fd688df5d8413b-ce56a2b1a95f241c593b-38ba44d03e9c8a443da76978705f0cb0d9c265ae', '2021-06-18 13:34:04', 'awaiting_payment', '10.00', '35a4ynCruUzQy4hFVg6Xm9QVoJTyUgQTNS', 3, '0', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;35a4ynCruUzQy4hFVg6Xm9QVoJTyUgQTNS&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00037198', '0.00607562', 'BTC', 'GBP', ''),
(84, '3b7e32b619bff3d3f08a-d5a7fcdc56969e5484bc-e4ac64cdfeaeb03c7dcd6fa5de0f0daf6fd5703e', '2021-06-18 15:12:24', 'awaiting_payment', '10.00', '3KmVUr5nEANwgQtn9sNYXLhNX78uh9vnHN', 3, '0', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;3KmVUr5nEANwgQtn9sNYXLhNX78uh9vnHN&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00037613', '0.00613339', 'BTC', 'GBP', ''),
(85, '2e69555efeebd04c51ab-c259b1c6915ea07136fe-fc33d0e3851b03710adcca7bd08fba0817ff53c3', '2021-06-18 15:25:43', 'awaiting_payment', '10.00', '33Edy1GCPsXyZJH9yUKwS1FPMJb9s8JYbJ', 3, '0', '0', 'Please send the payment amount shown above to the following Bitcoin address:&lt;br&gt;&lt;b&gt;&lt;a href=javascript:void(0) onclick=copyToClipboard(this)&gt;33Edy1GCPsXyZJH9yUKwS1FPMJb9s8JYbJ&lt;/a&gt;&lt;/b&gt;&lt;br&gt;The current estimated fee is:&lt;br&gt;&lt;b&gt;0.00001000 BTC &lt;i class=&#039;fab fa-btc&#039;&gt;&lt;/i&gt;&lt;/b&gt;', '0.00037672', '0.0061621', 'BTC', 'GBP', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp(),
  `currency` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `dateCreated`, `currency`) VALUES
(1, 'Test Product', 'This is a test product. Do not buy it.', 20.00, '2021-04-08 12:53:02', 'GBP'),
(2, 'Example Product', 'This is a test product. Do not buy it.', 20.00, '2021-04-08 12:53:02', 'USD'),
(3, 'Third Product', 'This is a test product. Do not buy it.', 10.00, '2021-04-08 12:53:02', 'GBP');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
