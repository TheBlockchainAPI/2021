<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
include __DIR__ . "/helpers/BlockchainAPI.php";
$layouts->header();

$error = null;
$result = null;

// Check order post
if(isset($_POST['checkfees'])) {
  if(isset($_POST['coin'])) {
    $coin = $_POST['coin'];

    if($coin == 'btc') {
      // Using the helper functions to check logs
      $result = $btcHelpers::checkfees();
    } else if($coin == 'eth') {
      // Using the helper functions to check logs
      $result = $ethHelpers::checkfees();
    } else {
      $error = 'You must select a coin';
    }
  }
}

?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Check Fees</h1>
  <p class="lead">Check the current fee prices for your chosen coin</p>
</div>


<div class="container">

  <div class="mb-3 text-center">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST">
      <!-- Let's just create a really simple product we can use our system with -->
      <div class="row">

        <?php

          if(!empty($error)) {
            echo '
            <div class="alert alert-danger" style="width: 100%;" role="alert">
              '.$error.'
            </div>
            ';
          }

          if(!empty($result)) {
            echo '
            <div class="alert alert-success" style="width: 100%; min-height: 500px;" role="alert">
              <pre style="min-height: 500px; text-align: left; color: white;"><code>'.$result.'</code></pre>
            </div>
            ';
          }

        ?>

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-body">
            <div class="form-group">
              <select class="form-control" name="coin" onchange="change(this)">
                <option value="none">Select a coin</option>
                <option value="eth">ETH</option>
                <option value="btc">BTC</option>
              </select>
            </div>

            <button type="submit" name="checkfees" class="btn btn-lg btn-block btn-primary">Check Fees</button>

<div style="max-width: 100%!important; margin-top: 20px;">
<pre class="code code-php"><label>PHP</label><code>$api_base = "https://blockchainapi.org/api/<b><span style="color: yellow;" id="type">eth</span></b>?method=check_fees";

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $api_base
));

$response = curl_exec($curl);
$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($http_status_code == 200) {
    $decoded = json_decode($response, true);
    if($decoded['success']) {
      return json_encode($decoded['success'], JSON_PRETTY_PRINT);
    } else {
      return json_encode(array('error' => 'Failed to get fees'), JSON_PRETTY_PRINT);
    }
} else {
    return $response;
}</code></pre>
</div>

          </div>
        </div>

      </div>
    </form>
  </div>

  <script type="text/javascript">
    function change(tru) {
      $('#type').html(tru.value);
    }
  </script>

<?php
    $layouts->footer();
?>