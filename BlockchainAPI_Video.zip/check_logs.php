<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
include __DIR__ . "/helpers/BlockchainAPI.php";
$layouts->header();

$error = null;
$result = null;

// Check order post
if(isset($_POST['checklogs'])) {
  if(isset($_POST['callback']) && isset($_POST['coin'])) {

    $callback = $_POST['callback'];
    $coin = $_POST['coin'];

    if($coin == 'BTC') {
      // Using the helper functions to check logs
      $result = $btcHelpers::checkLogs($callback);
    } else if($coin == 'ETH') {
      // Using the helper functions to check logs
      $result = $ethHelpers::checkLogs($callback);
    } else {
      $error = 'You must select a coin';
    }
  }
}

?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Check Logs</h1>
  <p class="lead">Enter your callback url and check all of the transactions for that url</p>
</div>


<div class="container">

  <div class="mb-3 text-center">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST">
      <!-- Let's just create a really simple product we can use our system with -->
      <div class="row">

        <?php

          if(!empty($error)) {
            echo '
            <div class="alert alert-danger" style="width: 100%;" role="alert">
              '.$error.'
            </div>
            ';
          }

          if(!empty($result)) {
            echo '
            <div class="alert alert-success" style="width: 100%; min-height: 500px;" role="alert">
              <pre style="min-height: 500px; text-align: left; color: white;"><code>'.$result.'</code></pre>
            </div>
            ';
          }

        ?>

        <div class="card mb-4 box-shadow" style="width: 100%;">
          <div class="card-body">
            <div class="form-group">
              <select class="form-control" name="coin">
                <option value="none">Select a coin</option>
                <option value="ETH">ETH</option>
                <option value="BTC">BTC</option>
              </select>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="callback" style="text-align: center;" placeholder="Enter your callback url">
            </div>

            <button type="submit" name="checklogs" class="btn btn-lg btn-block btn-primary">Check Order</button>

          </div>
        </div>

      </div>
    </form>
  </div>

<?php
    $layouts->footer();
?>