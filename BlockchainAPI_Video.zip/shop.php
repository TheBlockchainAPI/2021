<?php
use Jimmerioles\BitcoinCurrencyConverter\Provider\CoinbaseProvider;
include __DIR__ . "/includes/init.php";
$layouts->header();
?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Products</h1>
  <p class="lead">Browse our products below</p>
</div>


<div class="container">

  <div class="card-deck mb-3 text-center">
    <!-- This form will be posted to processOrder.php -->
    <form method="POST" action="./orderNew.php">
      <!-- Let's just create a really simple product we can use our system with -->
      <div class="row">
      <?php foreach ($functions->getProducts() as $product) { ?>
        <input type="hidden" name="product" value="<?= $product['id']; ?>">
        <div class="card mb-4 box-shadow">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal"><?= $product['name']; ?></h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title"><?= $functions->getCurrencySymbol($product['currency']); ?><?= $product['price']; ?> <?= $product['currency']; ?></h1>
            <h1 class="card-title pricing-card-title" style="font-size: 14px;"><?=$convert->toBtc($product['price'], $product['currency']);?> <i class="fab fa-btc"></i> BTC</h1>
            <h1 class="card-title pricing-card-title" style="font-size: 14px;"><?=$convert->toCurrency('ETH', $convert->toBtc($product['price'], $product['currency']));?> <i class="fab fa-ethereum"></i> ETH</h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li><?= $product['description']; ?></li>
            </ul>
            <button type="submit" name="buyNow" class="btn btn-lg btn-block btn-primary">Buy now</button>
          </div>
        </div>
      <?php } ?>
      </div>
    </form>
  </div>

<?php
    $layouts->footer();
?>